#Welcome to the 1st program on Python. Lets get Started!!
print("Hello World")
